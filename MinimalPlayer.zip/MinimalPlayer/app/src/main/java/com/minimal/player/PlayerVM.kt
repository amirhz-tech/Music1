package com.minimal.player

import android.app.Application
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import kotlinx.coroutines.*

data class Song(
    val id: Long, val title: String, val artist: String,
    val uri: Uri, val folder: String, val durationMs: Long
)

/** Finds every mp3 on the device, keeping its real folder path. */
fun scanSongs(ctx: Context): List<Song> {
    val m = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val proj = arrayOf(
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION,
        MediaStore.Audio.Media.DATA
    )
    val sel = "(${MediaStore.Audio.Media.MIME_TYPE} = ? OR ${MediaStore.Audio.Media.DATA} LIKE ?) " +
        "AND ${MediaStore.Audio.Media.IS_RINGTONE} = 0 AND ${MediaStore.Audio.Media.IS_NOTIFICATION} = 0 " +
        "AND ${MediaStore.Audio.Media.IS_ALARM} = 0"
    val out = mutableListOf<Song>()
    ctx.contentResolver.query(
        m, proj, sel, arrayOf("audio/mpeg", "%.mp3"),
        "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE"
    )?.use { c ->
        while (c.moveToNext()) {
            val id = c.getLong(0)
            val path = c.getString(4) ?: ""
            out += Song(
                id = id,
                title = c.getString(1) ?: path.substringAfterLast('/'),
                artist = c.getString(2)?.takeIf { it != "<unknown>" } ?: "Unknown artist",
                uri = ContentUris.withAppendedId(m, id),
                folder = path.substringBeforeLast('/', "Unknown"),
                durationMs = c.getLong(3)
            )
        }
    }
    return out
}

class PlaylistStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("playlists", Context.MODE_PRIVATE)
    fun load(): Map<String, List<Long>> = sp.all.mapNotNull { (k, v) ->
        (v as? String)?.let { k to it.split(",").mapNotNull(String::toLongOrNull) }
    }.toMap()
    fun save(name: String, ids: List<Long>) = sp.edit().putString(name, ids.joinToString(",")).apply()
    fun delete(name: String) = sp.edit().remove(name).apply()
}

object PlayerHolder {
    private var p: ExoPlayer? = null
    fun get(c: Context): ExoPlayer = p ?: ExoPlayer.Builder(c.applicationContext)
        .setAudioAttributes(
            AudioAttributes.Builder().setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .setUsage(C.USAGE_MEDIA).build(), true
        )
        .setHandleAudioBecomingNoisy(true)
        .build().also { p = it }
}

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    override fun onCreate() {
        super.onCreate()
        session = MediaSession.Builder(this, PlayerHolder.get(this)).build()
    }
    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = session
    override fun onDestroy() {
        session?.release(); session = null
        super.onDestroy()
    }
}

class PlayerVM(app: Application) : AndroidViewModel(app) {
    val player = PlayerHolder.get(app)
    private val store = PlaylistStore(app)

    var songs by mutableStateOf<List<Song>>(emptyList())
    var playlists by mutableStateOf(store.load())
    var current by mutableStateOf<Song?>(null)
    var playing by mutableStateOf(false)
    var repeat by mutableIntStateOf(Player.REPEAT_MODE_OFF)
    var shuffle by mutableStateOf(false)
    var position by mutableLongStateOf(0L)
    var duration by mutableLongStateOf(0L)

    init {
        player.addListener(object : Player.Listener {
            override fun onEvents(p: Player, events: Player.Events) = sync()
        })
        sync()
        viewModelScope.launch { while (true) { position = player.currentPosition; delay(500) } }
    }

    private fun sync() {
        playing = player.isPlaying
        repeat = player.repeatMode
        shuffle = player.shuffleModeEnabled
        val id = player.currentMediaItem?.mediaId?.toLongOrNull()
        current = songs.firstOrNull { it.id == id }
        duration = maxOf(player.duration, 0L)
    }

    fun scan() {
        viewModelScope.launch {
            songs = withContext(Dispatchers.IO) { scanSongs(getApplication()) }
            sync()
        }
    }

    fun play(queue: List<Song>, index: Int) {
        player.setMediaItems(queue.map {
            MediaItem.Builder().setMediaId(it.id.toString()).setUri(it.uri)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(it.title).setArtist(it.artist).build())
                .build()
        }, index, 0L)
        player.prepare()
        player.play()
    }

    fun toggle() { if (player.isPlaying) player.pause() else player.play() }
    fun next() = player.seekToNext()
    fun prev() = player.seekToPrevious()
    fun seek(ms: Long) = player.seekTo(ms)
    fun toggleShuffle() { player.shuffleModeEnabled = !player.shuffleModeEnabled }
    /** Off -> Repeat all -> Repeat one -> Off */
    fun toggleRepeat() {
        player.repeatMode = when (player.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun playlistSongs(name: String): List<Song> {
        val m = songs.associateBy { it.id }
        return playlists[name].orEmpty().mapNotNull { m[it] }
    }
    fun savePlaylist(name: String, ids: List<Long>) { store.save(name, ids); playlists = store.load() }
    fun deletePlaylist(name: String) { store.delete(name); playlists = store.load() }
}
