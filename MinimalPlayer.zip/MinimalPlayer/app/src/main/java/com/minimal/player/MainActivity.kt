package com.minimal.player

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

class MainActivity : ComponentActivity() {
    private var future: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val transparent = android.graphics.Color.TRANSPARENT
        enableEdgeToEdge(SystemBarStyle.dark(transparent), SystemBarStyle.dark(transparent))
        future = MediaController.Builder(this, SessionToken(this, ComponentName(this, PlaybackService::class.java))).buildAsync()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color.White, onPrimary = Color.Black,
                    background = Color.Black, surface = Color.Black,
                    onBackground = Color.White, onSurface = Color.White,
                    secondaryContainer = Color(0xFF2A2A2A), onSecondaryContainer = Color.White
                )
            ) { Surface(Modifier.fillMaxSize(), color = Color.Black) { App() } }
        }
    }

    override fun onDestroy() {
        future?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)

@Composable
fun App(vm: PlayerVM = viewModel()) {
    val ctx = LocalContext.current
    val audioPerm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE
    val perms = if (Build.VERSION.SDK_INT >= 33) arrayOf(audioPerm, Manifest.permission.POST_NOTIFICATIONS)
    else arrayOf(audioPerm)
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, audioPerm) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        granted = r[audioPerm] == true
        if (granted) vm.scan()
    }
    LaunchedEffect(Unit) { if (granted) vm.scan() else launcher.launch(perms) }

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var folder by rememberSaveable { mutableStateOf<String?>(null) }
    var plist by rememberSaveable { mutableStateOf<String?>(null) }
    var showNow by rememberSaveable { mutableStateOf(false) }
    var picker by remember { mutableStateOf<Pair<String, List<Long>>?>(null) }
    var askName by remember { mutableStateOf(false) }
    var qSongs by rememberSaveable { mutableStateOf("") }
    var qFolders by rememberSaveable { mutableStateOf("") }
    var qLists by rememberSaveable { mutableStateOf("") }

    val pal = remember(vm.accent) { Pal(vm.accent) }
    val shift by animateFloatAsState(listOf(0f, 55f, -45f, 25f)[tab], label = "shift")

    BackHandler(enabled = showNow || picker != null || folder != null || plist != null) {
        if (showNow) showNow = false
        else if (picker != null) picker = null
        else if (plist != null) plist = null
        else folder = null
    }

    CompositionLocalProvider(LocalPal provides pal) {
        Backdrop(shift) {
            Scaffold(
                containerColor = Color.Transparent,
                bottomBar = {
                    Column(Modifier.navigationBarsPadding()) {
                        MiniPlayer(vm) { showNow = true }
                        GlassNav(tab) { i -> tab = i; folder = null; plist = null }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize().statusBarsPadding()) {
                    if (!granted) {
                        Column(
                            Modifier.fillMaxSize().padding(32.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("Allow access to your storage so I can find your music.", textAlign = TextAlign.Center)
                            Spacer(Modifier.height(16.dp))
                            Button(
                                { launcher.launch(perms) },
                                colors = ButtonDefaults.buttonColors(containerColor = pal.light, contentColor = Color.Black)
                            ) { Text("Allow access") }
                        }
                    } else when (tab) {
                        0 -> Column {
                            Header("Songs", null)
                            SearchField(qSongs, "Search songs") { qSongs = it }
                            val shown = vm.songs.matching(qSongs)
                            if (vm.songs.isEmpty()) Empty("No MP3 files found")
                            else if (shown.isEmpty()) Empty("No songs match")
                            else SongList(shown, vm.current, Modifier.weight(1f)) { vm.play(shown, it) }
                        }
                        1 -> {
                            val f = folder
                            if (f == null) Column {
                                Header("Folders", null)
                                SearchField(qFolders, "Search folders") { qFolders = it }
                                val all = remember(vm.songs) {
                                    vm.songs.groupBy { it.folder }.toList().sortedBy { it.first.lowercase() }
                                }
                                val groups = all.filter { it.first.substringAfterLast('/').contains(qFolders.trim(), true) }
                                if (all.isEmpty()) Empty("No MP3 files found")
                                else if (groups.isEmpty()) Empty("No folders match")
                                else LazyColumn(
                                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(groups, key = { it.first }) { (path, list) ->
                                        ListCard(Icons.Filled.Folder, path.substringAfterLast('/'), "${list.size} songs") { folder = path }
                                    }
                                }
                            } else Column {
                                val list = vm.songs.filter { it.folder == f }
                                Header(f.substringAfterLast('/'), { folder = null })
                                SongList(list, vm.current, Modifier.weight(1f)) { vm.play(list, it) }
                            }
                        }
                        2 -> {
                            val p = plist
                            if (p == null) Column {
                                Header("Playlists", null) {
                                    IconButton({ askName = true }) { Icon(Icons.Filled.Add, "New playlist", tint = pal.light) }
                                }
                                SearchField(qLists, "Search playlists") { qLists = it }
                                val names = vm.playlists.keys.sorted().filter { it.contains(qLists.trim(), true) }
                                if (vm.playlists.isEmpty()) {
                                    Column(
                                        Modifier.fillMaxWidth().padding(16.dp).glass(24.dp).clickable { askName = true }.padding(28.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Icon(Icons.Filled.QueueMusic, null, Modifier.size(56.dp), tint = pal.light)
                                        Spacer(Modifier.height(12.dp))
                                        Text("Create a playlist", style = MaterialTheme.typography.titleMedium)
                                        Text("Tap to pick songs from your library", color = Muted, style = MaterialTheme.typography.bodySmall)
                                    }
                                } else if (names.isEmpty()) Empty("No playlists match")
                                else LazyColumn(
                                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(names, key = { it }) { name ->
                                        ListCard(Icons.Filled.QueueMusic, name, "${vm.playlistSongs(name).size} songs") { plist = name }
                                    }
                                }
                            } else Column {
                                val list = vm.playlistSongs(p)
                                Header(p, { plist = null }) {
                                    IconButton({ picker = p to vm.playlists[p].orEmpty() }) { Icon(Icons.Filled.Edit, "Edit songs", tint = pal.light) }
                                    IconButton({ vm.deletePlaylist(p); plist = null }) { Icon(Icons.Filled.Delete, "Delete", tint = pal.light) }
                                }
                                if (list.isEmpty()) Empty("Empty playlist. Tap the pencil to add songs.")
                                else SongList(list, vm.current, Modifier.weight(1f)) { vm.play(list, it) }
                            }
                        }
                        else -> SettingsScreen(vm)
                    }
                }
            }

            if (showNow) NowPlaying(vm) { showNow = false }

            picker?.let { (name, initial) ->
                Picker(vm.songs, initial, onCancel = { picker = null }) { ids ->
                    vm.savePlaylist(name, ids); picker = null; tab = 2; plist = name
                }
            }
        }

        if (askName) {
            var n by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { askName = false },
                containerColor = Color(0xFF16161F),
                shape = RoundedCornerShape(28.dp),
                title = { Text("New playlist") },
                text = {
                    OutlinedTextField(
                        n, { n = it }, singleLine = true, placeholder = { Text("Name", color = Muted) },
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = pal.light, cursorColor = pal.light)
                    )
                },
                confirmButton = {
                    TextButton(
                        {
                            if (n.isNotBlank()) {
                                val name = n.trim()
                                picker = name to vm.playlists[name].orEmpty()
                                askName = false
                            }
                        },
                        colors = ButtonDefaults.textButtonColors(contentColor = pal.light)
                    ) { Text("Next") }
                },
                dismissButton = {
                    TextButton({ askName = false }, colors = ButtonDefaults.textButtonColors(contentColor = Muted)) { Text("Cancel") }
                }
            )
        }
    }
}

@Composable
fun GlassNav(tab: Int, onTab: (Int) -> Unit) {
    val pal = LocalPal.current
    val items = listOf(
        "Songs" to Icons.Filled.MusicNote, "Folders" to Icons.Filled.Folder,
        "Playlists" to Icons.Filled.QueueMusic, "Settings" to Icons.Filled.Settings
    )
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp).glass(30.dp, 0.14f).padding(6.dp)
    ) {
        items.forEachIndexed { i, (label, icon) ->
            val on = tab == i
            val c = if (on) pal.light else Color.White.copy(alpha = 0.55f)
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(24.dp))
                    .background(if (on) pal.light.copy(alpha = 0.22f) else Color.Transparent)
                    .clickable { onTab(i) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(icon, label, tint = c)
                Text(label, color = c, fontSize = 11.sp, maxLines = 1)
            }
        }
    }
}

@Composable
fun Header(title: String, onBack: (() -> Unit)?, actions: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Back") }
        Text(
            title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
        )
        actions()
    }
}

@Composable
fun Empty(text: String) = Box(Modifier.fillMaxSize(), Alignment.Center) { Text(text, color = Muted) }

@Composable
fun ListCard(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().glass(16.dp, 0.09f).clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(pal.light.copy(alpha = 0.2f)), Alignment.Center) {
            Icon(icon, null, tint = pal.light)
        }
        Column(Modifier.padding(start = 14.dp)) {
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = Muted, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun SongList(songs: List<Song>, current: Song?, modifier: Modifier = Modifier, onPlay: (Int) -> Unit) {
    val pal = LocalPal.current
    LazyColumn(
        modifier, contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
            val on = s.id == current?.id
            Row(
                Modifier.fillMaxWidth().glass(16.dp, if (on) 0.18f else 0.09f).clickable { onPlay(i) }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        s.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                        color = if (on) pal.light else Color.White
                    )
                    Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted, style = MaterialTheme.typography.bodySmall)
                }
                Text(fmt(s.durationMs), color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun Picker(songs: List<Song>, initial: List<Long>, onCancel: () -> Unit, onDone: (List<Long>) -> Unit) {
    val pal = LocalPal.current
    val sel = remember { mutableStateListOf<Long>().apply { addAll(initial) } }
    var q by remember { mutableStateOf("") }
    Backdrop(0f) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            Header("Select songs (${sel.size})", onCancel) {
                Button(
                    { onDone(sel.toList()) },
                    colors = ButtonDefaults.buttonColors(containerColor = pal.light, contentColor = Color.Black)
                ) { Text("Save") }
            }
            SearchField(q, "Search songs to add") { q = it }
            val shown = songs.matching(q)
            if (shown.isEmpty()) Empty("No songs match")
            else LazyColumn(
                Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(shown, key = { it.id }) { s ->
                    val on = s.id in sel
                    Row(
                        Modifier.fillMaxWidth().glass(16.dp, 0.09f).clickable { if (on) sel.remove(s.id) else sel.add(s.id) }
                            .padding(start = 16.dp, end = 12.dp, top = 8.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(
                            checked = on, onCheckedChange = null,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF111111), checkedTrackColor = pal.light,
                                checkedBorderColor = Color.Transparent,
                                uncheckedThumbColor = Color.White.copy(alpha = 0.7f),
                                uncheckedTrackColor = Color.White.copy(alpha = 0.12f),
                                uncheckedBorderColor = Color.White.copy(alpha = 0.3f)
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MiniPlayer(vm: PlayerVM, onOpen: () -> Unit) {
    val s = vm.current ?: return
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).glass(20.dp, 0.14f)
            .clickable(onClick = onOpen).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AlbumArt(s, Modifier.size(44.dp), 12.dp)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted, style = MaterialTheme.typography.bodySmall)
        }
        IconButton(vm::toggle) {
            Icon(if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play/Pause", tint = pal.light)
        }
    }
}

@Composable
fun NowPlaying(vm: PlayerVM, onClose: () -> Unit) {
    val s = vm.current ?: return
    val pal = LocalPal.current
    var drag by remember { mutableStateOf<Float?>(null) }
    val off = Color.White.copy(alpha = 0.45f)
    Backdrop(0f) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 28.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClose) { Icon(Icons.Filled.KeyboardArrowDown, "Close") }
                Text("Now playing", Modifier.weight(1f), textAlign = TextAlign.Center, color = Muted)
                Spacer(Modifier.size(48.dp))
            }
            Spacer(Modifier.weight(1f))
            AlbumArt(s, Modifier.fillMaxWidth().aspectRatio(1f), 32.dp)
            Spacer(Modifier.height(28.dp))
            Text(
                s.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold,
                maxLines = 2, textAlign = TextAlign.Center
            )
            Text(s.artist, color = Muted, maxLines = 1)
            Spacer(Modifier.height(20.dp))
            Slider(
                value = drag ?: vm.position.toFloat(),
                onValueChange = { drag = it },
                onValueChangeFinished = { drag?.let { vm.seek(it.toLong()) }; drag = null },
                valueRange = 0f..maxOf(vm.duration, 1L).toFloat(),
                colors = SliderDefaults.colors(
                    thumbColor = pal.light, activeTrackColor = pal.light,
                    inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                )
            )
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                Text(fmt((drag ?: vm.position.toFloat()).toLong()), color = Muted, style = MaterialTheme.typography.bodySmall)
                Text(fmt(vm.duration), color = Muted, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
                IconButton(vm::toggleShuffle) {
                    Icon(Icons.Filled.Shuffle, "Shuffle", tint = if (vm.shuffle) pal.light else off)
                }
                IconButton(vm::prev) { Icon(Icons.Filled.SkipPrevious, "Previous", Modifier.size(36.dp)) }
                FilledIconButton(
                    vm::toggle, Modifier.size(72.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = pal.light, contentColor = Color.Black)
                ) {
                    Icon(if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play/Pause", Modifier.size(40.dp))
                }
                IconButton(vm::next) { Icon(Icons.Filled.SkipNext, "Next", Modifier.size(36.dp)) }
                IconButton(vm::toggleRepeat) {
                    Icon(
                        if (vm.repeat == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        "Repeat", tint = if (vm.repeat == Player.REPEAT_MODE_OFF) off else pal.light
                    )
                }
            }
            Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
fun SettingsScreen(vm: PlayerVM) {
    val pal = LocalPal.current
    var ver by remember { mutableIntStateOf(0) }
    val presets = listOf(
        0xFF2DD4BF, 0xFF8B5CF6, 0xFF3B82F6, 0xFFEC4899,
        0xFFF97316, 0xFF22C55E, 0xFFEF4444, 0xFFEAB308
    ).map { it.toInt() }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Header("Settings", null)
        Text(
            "Theme", style = MaterialTheme.typography.titleMedium, color = pal.light,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )
        Column(
            Modifier.padding(horizontal = 16.dp).fillMaxWidth().glass(24.dp).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Pick your own colour. The whole app follows it.", color = Muted, style = MaterialTheme.typography.bodySmall)
            key(ver) { ColorPicker(vm.accent) { vm.setAccent(it) } }
            Text("Presets", color = Muted, style = MaterialTheme.typography.bodySmall)
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                presets.forEach { c ->
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                            .border(2.dp, if (vm.accent == c) Color.White else Color.Transparent, CircleShape)
                            .clickable { vm.setAccent(c); ver++ }
                    )
                }
            }
            TextButton(
                { vm.setAccent(ThemeStore.DEFAULT); ver++ },
                colors = ButtonDefaults.textButtonColors(contentColor = pal.light)
            ) { Text("Reset to default") }
        }
        Spacer(Modifier.height(24.dp))
    }
}

fun List<Song>.matching(q: String): List<Song> {
    val t = q.trim()
    return if (t.isEmpty()) this else filter { it.title.contains(t, true) || it.artist.contains(t, true) }
}

@Composable
fun SearchField(query: String, hint: String, onChange: (String) -> Unit) {
    val focus = LocalFocusManager.current
    val pal = LocalPal.current
    OutlinedTextField(
        value = query, onValueChange = onChange, singleLine = true,
        placeholder = { Text(hint, color = Muted) },
        leadingIcon = { Icon(Icons.Filled.Search, null, tint = Muted) },
        trailingIcon = {
            if (query.isNotEmpty()) IconButton({ onChange("") }) { Icon(Icons.Filled.Close, "Clear") }
        },
        shape = RoundedCornerShape(28.dp),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() }),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = pal.light, unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
            cursorColor = pal.light,
            focusedContainerColor = Color.White.copy(alpha = 0.10f),
            unfocusedContainerColor = Color.White.copy(alpha = 0.08f)
        ),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
    )
}
