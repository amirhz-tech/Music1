# Minimal Player
Build the APK: open this folder in Android Studio -> Build > Build APK(s),
or push to GitHub: the Actions tab builds it and attaches app-debug.apk.
