package com.minimal.player

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.LruCache
import android.util.Size
import java.util.concurrent.ConcurrentHashMap

/** Loads album art: embedded MP3 picture first, then the system thumbnail. */
object ArtCache {
    private val cache = LruCache<Long, Bitmap>(24)
    private val missing = ConcurrentHashMap.newKeySet<Long>()

    fun get(ctx: Context, s: Song): Bitmap? {
        cache.get(s.id)?.let { return it }
        if (s.id in missing) return null
        var bmp: Bitmap? = runCatching {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, s.uri)
                r.embeddedPicture?.let { decode(it) }
            } finally {
                r.release()
            }
        }.getOrNull()
        if (bmp == null && Build.VERSION.SDK_INT >= 29) {
            bmp = runCatching { ctx.contentResolver.loadThumbnail(s.uri, Size(600, 600), null) }.getOrNull()
        }
        if (bmp != null) cache.put(s.id, bmp) else missing.add(s.id)
        return bmp
    }

    private fun decode(b: ByteArray): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var sample = 1
        while (o.outWidth / sample > 800) sample *= 2
        return BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = sample })
    }
}
