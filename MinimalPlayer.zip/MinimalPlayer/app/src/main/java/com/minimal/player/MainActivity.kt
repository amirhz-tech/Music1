package com.minimal.player

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

class MainActivity : ComponentActivity() {
    private var future: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val transparent = android.graphics.Color.TRANSPARENT
        enableEdgeToEdge(SystemBarStyle.dark(transparent), SystemBarStyle.dark(transparent))
        // Connecting a controller starts the playback service (background play + notification).
        future = MediaController.Builder(this, SessionToken(this, ComponentName(this, PlaybackService::class.java))).buildAsync()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color.White, onPrimary = Color.Black,
                    background = Color.Black, surface = Color.Black,
                    onBackground = Color.White, onSurface = Color.White,
                    secondaryContainer = Color(0xFF2A2A2A), onSecondaryContainer = Color.White
                )
            ) { Surface(Modifier.fillMaxSize(), color = Color.Black) { App() } }
        }
    }

    override fun onDestroy() {
        future?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

private val Dim = Color(0xFF666666)
private val NoBg = Color.Transparent
fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)

@Composable
fun App(vm: PlayerVM = viewModel()) {
    val ctx = LocalContext.current
    val audioPerm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE
    val perms = if (Build.VERSION.SDK_INT >= 33) arrayOf(audioPerm, Manifest.permission.POST_NOTIFICATIONS)
    else arrayOf(audioPerm)
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, audioPerm) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        granted = r[audioPerm] == true
        if (granted) vm.scan()
    }
    LaunchedEffect(Unit) { if (granted) vm.scan() else launcher.launch(perms) }

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var folder by rememberSaveable { mutableStateOf<String?>(null) }
    var plist by rememberSaveable { mutableStateOf<String?>(null) }
    var showNow by rememberSaveable { mutableStateOf(false) }
    var picker by remember { mutableStateOf<Pair<String, List<Long>>?>(null) }
    var askName by remember { mutableStateOf(false) }
    var qSongs by rememberSaveable { mutableStateOf("") }
    var qFolders by rememberSaveable { mutableStateOf("") }
    var qLists by rememberSaveable { mutableStateOf("") }

    BackHandler(enabled = showNow || picker != null || folder != null || plist != null) {
        if (showNow) showNow = false
        else if (picker != null) picker = null
        else if (plist != null) plist = null
        else folder = null
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = Color.Black,
            bottomBar = {
                Column {
                    MiniPlayer(vm) { showNow = true }
                    NavigationBar(containerColor = Color.Black) {
                        listOf(
                            "Songs" to Icons.Filled.MusicNote,
                            "Folders" to Icons.Filled.Folder,
                            "Playlists" to Icons.Filled.QueueMusic
                        ).forEachIndexed { i, (label, icon) ->
                            NavigationBarItem(
                                selected = tab == i,
                                onClick = { tab = i; folder = null; plist = null },
                                icon = { Icon(icon, label) }, label = { Text(label) }
                            )
                        }
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize().statusBarsPadding()) {
                if (!granted) {
                    Column(
                        Modifier.fillMaxSize().padding(32.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Allow access to your storage so I can find your music.", textAlign = TextAlign.Center)
                        Spacer(Modifier.height(16.dp))
                        Button({ launcher.launch(perms) }) { Text("Allow access") }
                    }
                } else when (tab) {
                    0 -> Column {
                        Header("Songs", null)
                        SearchField(qSongs, "Search songs") { qSongs = it }
                        val shown = vm.songs.matching(qSongs)
                        if (vm.songs.isEmpty()) Empty("No MP3 files found")
                        else if (shown.isEmpty()) Empty("No songs match")
                        else SongList(shown, vm.current, Modifier.weight(1f)) { vm.play(shown, it) }
                    }
                    1 -> {
                        val f = folder
                        if (f == null) Column {
                            Header("Folders", null)
                            SearchField(qFolders, "Search folders") { qFolders = it }
                            val all = remember(vm.songs) {
                                vm.songs.groupBy { it.folder }.toList().sortedBy { it.first.lowercase() }
                            }
                            val groups = all.filter { it.first.substringAfterLast('/').contains(qFolders.trim(), true) }
                            if (all.isEmpty()) Empty("No MP3 files found")
                            else if (groups.isEmpty()) Empty("No folders match")
                            LazyColumn {
                                items(groups, key = { it.first }) { (path, list) ->
                                    ListItem(
                                        headlineContent = { Text(path.substringAfterLast('/'), maxLines = 1) },
                                        supportingContent = { Text("${list.size} songs", color = Color.Gray) },
                                        leadingContent = { Icon(Icons.Filled.Folder, null) },
                                        colors = ListItemDefaults.colors(containerColor = NoBg),
                                        modifier = Modifier.clickable { folder = path }
                                    )
                                }
                            }
                        } else Column {
                            val list = vm.songs.filter { it.folder == f }
                            Header(f.substringAfterLast('/'), { folder = null })
                            SongList(list, vm.current, Modifier.weight(1f)) { vm.play(list, it) }
                        }
                    }
                    else -> {
                        val p = plist
                        if (p == null) Column {
                            Header("Playlists", null) {
                                IconButton({ askName = true }) { Icon(Icons.Filled.Add, "New playlist") }
                            }
                            SearchField(qLists, "Search playlists") { qLists = it }
                            val names = vm.playlists.keys.sorted().filter { it.contains(qLists.trim(), true) }
                            if (vm.playlists.isEmpty()) Empty("Tap + to create a playlist")
                            else if (names.isEmpty()) Empty("No playlists match")
                            LazyColumn {
                                items(names, key = { it }) { name ->
                                    ListItem(
                                        headlineContent = { Text(name, maxLines = 1) },
                                        supportingContent = { Text("${vm.playlistSongs(name).size} songs", color = Color.Gray) },
                                        leadingContent = { Icon(Icons.Filled.QueueMusic, null) },
                                        colors = ListItemDefaults.colors(containerColor = NoBg),
                                        modifier = Modifier.clickable { plist = name }
                                    )
                                }
                            }
                        } else Column {
                            val list = vm.playlistSongs(p)
                            Header(p, { plist = null }) {
                                IconButton({ picker = p to vm.playlists[p].orEmpty() }) { Icon(Icons.Filled.Edit, "Edit songs") }
                                IconButton({ vm.deletePlaylist(p); plist = null }) { Icon(Icons.Filled.Delete, "Delete") }
                            }
                            if (list.isEmpty()) Empty("Empty playlist. Tap the pencil to add songs.")
                            else SongList(list, vm.current, Modifier.weight(1f)) { vm.play(list, it) }
                        }
                    }
                }
            }
        }

        if (showNow) NowPlaying(vm) { showNow = false }

        picker?.let { (name, initial) ->
            Picker(vm.songs, initial, onCancel = { picker = null }) { ids ->
                vm.savePlaylist(name, ids); picker = null; tab = 2; plist = name
            }
        }
    }

    if (askName) {
        var n by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { askName = false },
            title = { Text("New playlist") },
            text = { OutlinedTextField(n, { n = it }, singleLine = true, placeholder = { Text("Name") }) },
            confirmButton = {
                TextButton({
                    if (n.isNotBlank()) {
                        val name = n.trim()
                        picker = name to vm.playlists[name].orEmpty()
                        askName = false
                    }
                }) { Text("Next") }
            },
            dismissButton = { TextButton({ askName = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun Header(title: String, onBack: (() -> Unit)?, actions: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Back") }
        Text(
            title, style = MaterialTheme.typography.titleLarge, maxLines = 1,
            modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
        )
        actions()
    }
}

@Composable
fun Empty(text: String) = Box(Modifier.fillMaxSize(), Alignment.Center) { Text(text, color = Color.Gray) }

@Composable
fun SongList(songs: List<Song>, current: Song?, modifier: Modifier = Modifier, onPlay: (Int) -> Unit) {
    LazyColumn(modifier) {
        itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
            val on = s.id == current?.id
            ListItem(
                headlineContent = { Text(s.title, maxLines = 1, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal) },
                supportingContent = { Text(s.artist, maxLines = 1, color = Color.Gray) },
                trailingContent = { Text(fmt(s.durationMs), color = Dim) },
                colors = ListItemDefaults.colors(containerColor = NoBg),
                modifier = Modifier.clickable { onPlay(i) }
            )
        }
    }
}

@Composable
fun Picker(songs: List<Song>, initial: List<Long>, onCancel: () -> Unit, onDone: (List<Long>) -> Unit) {
    val sel = remember { mutableStateListOf<Long>().apply { addAll(initial) } }
    var q by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding().imePadding()) {
        Header("Select songs (${sel.size})", onCancel) {
            TextButton({ onDone(sel.toList()) }) { Text("Save") }
        }
        SearchField(q, "Search songs to add") { q = it }
        val shown = songs.matching(q)
        if (shown.isEmpty()) Empty("No songs match")
        LazyColumn(Modifier.weight(1f)) {
            items(shown, key = { it.id }) { s ->
                val on = s.id in sel
                ListItem(
                    headlineContent = { Text(s.title, maxLines = 1) },
                    supportingContent = { Text(s.artist, maxLines = 1, color = Color.Gray) },
                    trailingContent = { Checkbox(on, null) },
                    colors = ListItemDefaults.colors(containerColor = NoBg),
                    modifier = Modifier.clickable { if (on) sel.remove(s.id) else sel.add(s.id) }
                )
            }
        }
    }
}

@Composable
fun MiniPlayer(vm: PlayerVM, onOpen: () -> Unit) {
    val s = vm.current ?: return
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF151515)).clickable(onClick = onOpen)
            .padding(horizontal = 16.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(s.title, maxLines = 1)
            Text(s.artist, maxLines = 1, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
        IconButton(vm::toggle) {
            Icon(if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play/Pause")
        }
    }
}

@Composable
fun NowPlaying(vm: PlayerVM, onClose: () -> Unit) {
    val s = vm.current ?: return
    var drag by remember { mutableStateOf<Float?>(null) }
    Column(
        Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth()) { IconButton(onClose) { Icon(Icons.Filled.KeyboardArrowDown, "Close") } }
        Spacer(Modifier.weight(1f))
        Icon(Icons.Filled.MusicNote, null, Modifier.size(120.dp), tint = Color(0xFF444444))
        Spacer(Modifier.height(32.dp))
        Text(s.title, style = MaterialTheme.typography.headlineSmall, maxLines = 2, textAlign = TextAlign.Center)
        Text(s.artist, color = Color.Gray)
        Spacer(Modifier.height(32.dp))
        Slider(
            value = drag ?: vm.position.toFloat(),
            onValueChange = { drag = it },
            onValueChangeFinished = { drag?.let { vm.seek(it.toLong()) }; drag = null },
            valueRange = 0f..maxOf(vm.duration, 1L).toFloat()
        )
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
            Text(fmt((drag ?: vm.position.toFloat()).toLong()), color = Color.Gray)
            Text(fmt(vm.duration), color = Color.Gray)
        }
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
            IconButton(vm::toggleShuffle) {
                Icon(Icons.Filled.Shuffle, "Shuffle", tint = if (vm.shuffle) Color.White else Dim)
            }
            IconButton(vm::prev) { Icon(Icons.Filled.SkipPrevious, "Previous", Modifier.size(36.dp)) }
            FilledIconButton(vm::toggle, Modifier.size(72.dp)) {
                Icon(if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play/Pause", Modifier.size(40.dp))
            }
            IconButton(vm::next) { Icon(Icons.Filled.SkipNext, "Next", Modifier.size(36.dp)) }
            IconButton(vm::toggleRepeat) {
                Icon(
                    if (vm.repeat == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    "Repeat",
                    tint = if (vm.repeat == Player.REPEAT_MODE_OFF) Dim else Color.White
                )
            }
        }
        Spacer(Modifier.weight(1f))
    }
}

fun List<Song>.matching(q: String): List<Song> {
    val t = q.trim()
    return if (t.isEmpty()) this else filter { it.title.contains(t, true) || it.artist.contains(t, true) }
}

@Composable
fun SearchField(query: String, hint: String, onChange: (String) -> Unit) {
    val focus = LocalFocusManager.current
    OutlinedTextField(
        value = query, onValueChange = onChange, singleLine = true,
        placeholder = { Text(hint, color = Dim) },
        leadingIcon = { Icon(Icons.Filled.Search, null, tint = Dim) },
        trailingIcon = {
            if (query.isNotEmpty()) IconButton({ onChange("") }) { Icon(Icons.Filled.Close, "Clear") }
        },
        shape = RoundedCornerShape(28.dp),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() }),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color.White, unfocusedBorderColor = Color(0xFF333333), cursorColor = Color.White
        ),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
    )
}
