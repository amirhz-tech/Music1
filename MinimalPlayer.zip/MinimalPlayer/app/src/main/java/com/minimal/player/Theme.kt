package com.minimal.player

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val Muted = Color.White.copy(alpha = 0.6f)

fun hsv(h: Float, s: Float, v: Float, a: Float = 1f): Color = Color(
    android.graphics.Color.HSVToColor(
        (a * 255).toInt(),
        floatArrayOf(((h % 360f) + 360f) % 360f, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f))
    )
)

/** Everything is derived from the one colour the user picks. */
class Pal(accentInt: Int) {
    val hue: Float
    val sat: Float
    val value: Float
    val light: Color

    init {
        val a = FloatArray(3)
        android.graphics.Color.colorToHSV(accentInt, a)
        hue = a[0]; sat = a[1]; value = a[2]
        light = hsv(hue, minOf(sat, 0.55f), 1f)
    }
}

val LocalPal = compositionLocalOf { Pal(ThemeStore.DEFAULT) }

fun Modifier.glass(radius: Dp = 18.dp, alpha: Float = 0.10f): Modifier {
    val shape = RoundedCornerShape(radius)
    return this.clip(shape)
        .background(Color.White.copy(alpha))
        .border(1.dp, Color.White.copy(0.16f), shape)
}

@Composable
fun Backdrop(shift: Float = 0f, content: @Composable BoxScope.() -> Unit) {
    val p = LocalPal.current
    val s = 0.15f + 0.5f * p.sat
    val v = 0.20f + 0.25f * p.value
    Box(
        Modifier.fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(
                        hsv(p.hue + shift, s, v + 0.05f),
                        hsv(p.hue + shift + 25f, s * 0.8f, 0.12f),
                        hsv(p.hue + shift - 40f, s, v)
                    )
                )
            )
            .background(
                Brush.radialGradient(
                    listOf(hsv(p.hue + shift + 140f, s, 0.55f, 0.28f), Color.Transparent),
                    center = Offset(950f, 350f), radius = 800f
                )
            ),
        content = content
    )
}

@Composable
fun AlbumArt(song: Song, modifier: Modifier, radius: Dp) {
    val ctx = LocalContext.current.applicationContext
    val pal = LocalPal.current
    val bmp by produceState<Bitmap?>(null, song.id) {
        value = null
        value = withContext(Dispatchers.IO) { ArtCache.get(ctx, song) }
    }
    Box(
        modifier.clip(RoundedCornerShape(radius))
            .background(Brush.linearGradient(listOf(pal.light.copy(alpha = 0.35f), Color.White.copy(alpha = 0.06f)))),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Filled.MusicNote, null, Modifier.fillMaxSize(0.4f), tint = Color.White.copy(alpha = 0.8f))
    }
}

/** Reports touch/drag position as 0..1 fractions of this element. */
fun Modifier.dragXY(onPos: (Float, Float) -> Unit): Modifier = pointerInput(Unit) {
    awaitEachGesture {
        val down = awaitFirstDown()
        onPos((down.position.x / size.width).coerceIn(0f, 1f), (down.position.y / size.height).coerceIn(0f, 1f))
        do {
            val ev = awaitPointerEvent()
            ev.changes.firstOrNull()?.let {
                onPos((it.position.x / size.width).coerceIn(0f, 1f), (it.position.y / size.height).coerceIn(0f, 1f))
                it.consume()
            }
        } while (ev.changes.any { it.pressed })
    }
}

@Composable
fun ColorPicker(color: Int, onChange: (Int) -> Unit) {
    val init = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(color, it) } }
    var h by remember { mutableFloatStateOf(init[0]) }
    var s by remember { mutableFloatStateOf(init[1]) }
    var v by remember { mutableFloatStateOf(init[2]) }
    val cb by rememberUpdatedState(onChange)
    val rainbow = remember { Brush.horizontalGradient((0..6).map { hsv(it * 60f, 1f, 1f) }) }
    val cur = android.graphics.Color.HSVToColor(floatArrayOf(h, s, v))

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(
            Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(16.dp))
                .background(Brush.horizontalGradient(listOf(Color.White, hsv(h, 1f, 1f))))
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black)))
                .dragXY { x, y -> s = x; v = 1f - y; cb(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v))) }
                .drawWithContent {
                    drawContent()
                    drawCircle(Color.White, 11.dp.toPx(), Offset(s * size.width, (1f - v) * size.height), style = Stroke(3.dp.toPx()))
                }
        )
        Box(
            Modifier.fillMaxWidth().height(30.dp).clip(RoundedCornerShape(15.dp))
                .background(rainbow)
                .dragXY { x, _ -> h = (x * 360f).coerceAtMost(359.9f); cb(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v))) }
                .drawWithContent {
                    drawContent()
                    drawCircle(Color.White, 12.dp.toPx(), Offset(h / 360f * size.width, size.height / 2f), style = Stroke(3.dp.toPx()))
                }
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(Color(cur)).border(1.dp, Color.White.copy(0.4f), RoundedCornerShape(12.dp)))
            Text("#%06X".format(cur and 0xFFFFFF), Modifier.padding(start = 12.dp), color = Muted)
        }
    }
}
